export default {

    getAddJourneyPlan(state)    {

        return state.add_journey_plan
    },

    getListeJourneyPlan(state)    {

        return state.liste_journey_plan
    }
}