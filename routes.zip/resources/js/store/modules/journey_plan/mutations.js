export default {

    setAddJourneyPlan(state, value) {

        state.add_journey_plan      =   value
    },

    setListeJourneyPlan(state, value) {

        state.liste_journey_plan    =   value
    }
}