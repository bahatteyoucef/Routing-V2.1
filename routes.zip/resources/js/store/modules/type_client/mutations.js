export default {

    setAddTypeClient(state, value) {

        state.add_type_client      =   value
    },

    setListeTypeClient(state, value) {

        state.liste_type_client    =   value
    }
}