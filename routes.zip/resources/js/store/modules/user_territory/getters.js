export default {

    getAddUserTerritory(state)    {

        return state.add_user_territory
    },

    getListeUserTerritory(state)    {

        return state.liste_user_territory
    }
}