export default {

    setAddUserTerritory(state, value) {

        state.add_user_territory        =   value
    },

    setListeUserTerritory(state, value) {

        state.liste_user_territory      =   value
    }
}