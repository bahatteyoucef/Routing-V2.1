export default {

    getAddJournee(state)    {

        return state.add_journee
    },

    getListeJournee(state)    {

        return state.liste_journee
    }
}