export default {

    setAddJournee(state, value) {

        state.add_journee      =   value
    },

    setListeJournee(state, value) {

        state.liste_journee    =   value
    }
}