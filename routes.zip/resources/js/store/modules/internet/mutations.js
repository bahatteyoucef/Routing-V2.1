export default {

    setIsOnline(state, value) {

        state.is_online             =   value
    },
}