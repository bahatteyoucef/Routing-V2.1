<template>
    <!--
    <div>
        <div id="internet_error_screen">
            <div class="text-center align-middle center_screen_internet_error_screen">
                <div>
                    <img src="/images/no_internet_error.png" style="width : 50%;height : auto"/>

                    <div>
                        <div class="mt-3">
                            <h1 class="fw-bold text-secondary"> Oooooops ! </h1>
                        </div>

                        <div class="mt-3">  
                            <p class="fw-bold mt-1 text-secondary mb-1"> No internet connection found </p>
                            <p class="fw-bold text-secondary"> Check your connection </p>
                        </div>
                    </div>
                    
                </div>
            </div>
        </div>
    </div>
    -->

    <div>

    </div>
</template>

