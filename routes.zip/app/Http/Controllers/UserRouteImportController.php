<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class UserRouteImportController extends Controller
{
    //
}
