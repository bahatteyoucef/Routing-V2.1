<?php

function validateLength()
{
    
}