export default {

    getAddTypeClient(state)    {

        return state.add_type_client
    },

    getListeTypeClient(state)    {

        return state.liste_type_client
    }
}