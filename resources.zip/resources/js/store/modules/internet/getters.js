export default {

    getIsOnline(state)  {

        return state.is_online
    },
}