<template>
    <div>
        <div id="loading_screen" style="display:none;">
            <div class="text-center align-middle center_screen">
                <div class="spinner-grow" role="status">
                </div>

                <div style="padding : 15px;">
                    <h4> Loading ... ! </h4>
                </div>
            </div>
        </div>
    </div>
</template>